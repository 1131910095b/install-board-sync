# Install Board Sync v4 — Outlook style calendar

新版功能：
- Outlook 风格周历视图（Group A | Group B 并列）
- Day 视图单日完整安排
- Map 视图显示当周地理分布
- Team 字段（在 Install Board 设置 Group A/B）
- Duration (hrs) 字段（预估时长，自动堆叠）
- Sign Proof PDF 自动同步显示
- 单 Job PDF / 整周 PDF / 整天 PDF 一键导出
